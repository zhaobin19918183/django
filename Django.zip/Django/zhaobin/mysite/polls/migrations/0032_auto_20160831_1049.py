# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('polls', '0031_auto_20160831_1046'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='blogentry',
            options={'verbose_name': '\u56fe\u7247\u4e0a\u4f20\u6d4b\u8bd5', 'verbose_name_plural': '\u56fe\u7247\u4e0a\u4f20\u6d4b\u8bd5'},
        ),
    ]
