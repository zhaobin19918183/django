# -*- coding:UTF-8 -*- ＃必须在第一行或者第二行
# -*- coding:gb2312 -*- ＃必须在第一行或者第二行
# -*- coding:GBK -*- ＃必须在第一行或者第二行
import sys
reload(sys)
sys.setdefaultencoding("utf-8")
from django.contrib.auth.models import User, Group
from rest_framework import serializers
from models import booklist

class UserSerializer(serializers.HyperlinkedModelSerializer):
        class Meta:
            model = User
            fields = ('url', 'username', 'email', 'groups')


class GroupSerializer(serializers.HyperlinkedModelSerializer):
        class Meta:
            model = Group
            fields = ('url', 'name')
class booklistSerializer(serializers.HyperlinkedModelSerializer):
        class Meta:
            model = booklist
            fields = ('name','date','number')