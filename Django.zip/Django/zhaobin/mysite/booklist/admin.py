from django.contrib import admin
from .models import carlist
# from booklist.models import

# admin.site.register(CarForm)
admin.site.register(carlist)


